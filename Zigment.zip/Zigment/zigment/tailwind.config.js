// tailwind.config.js
module.exports = {
  content: [
    './src/**/*.{js,jsx,ts,tsx}',  // Make sure this includes all your source files
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
